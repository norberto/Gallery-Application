create trigger IDS_ON_INSERT2
	before insert
	on MESSAGE_TEST2
	for each row
BEGIN
    SELECT MESSAGE_ID_SEQ.nextval
    INTO :new.id
    FROM dual;
  END;