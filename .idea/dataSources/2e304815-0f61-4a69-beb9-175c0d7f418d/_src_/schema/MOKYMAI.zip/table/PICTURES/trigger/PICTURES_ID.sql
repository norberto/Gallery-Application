create trigger PICTURES_ID
	before insert
	on PICTURES
	for each row
begin
select PIC_ID.NEXTVAL
INTO :NEW.ID
from dual;
end;
