create trigger POV_ID
	before insert
	on POV_IMG_TAG
	for each row
BEGIN
    SELECT POV_SEQ.NEXTVAL
    INTO   :new.id
    FROM   dual;
  END;