create trigger TEST_AI
	before insert
	on TEST
	for each row
begin 
  select test_sequence.NEXTVAL
  into :new.id
  from dual;
END;
  
