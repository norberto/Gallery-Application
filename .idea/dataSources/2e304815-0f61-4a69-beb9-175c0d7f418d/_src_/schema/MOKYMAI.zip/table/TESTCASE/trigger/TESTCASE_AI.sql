create trigger TESTCASE_AI
	before insert
	on TESTCASE
	for each row
begin 
  select testcase_sequence.NEXTVAL
  into :new.id
  from dual;
END;
