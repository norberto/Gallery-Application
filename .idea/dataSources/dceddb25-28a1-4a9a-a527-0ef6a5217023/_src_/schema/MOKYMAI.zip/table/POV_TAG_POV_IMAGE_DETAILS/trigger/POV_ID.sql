create trigger POV_ID
	before insert
	on POV_TAG_POV_IMAGE_DETAILS
	for each row
BEGIN
    SELECT POV_SEQ.NEXTVAL
    INTO   :new.id
    FROM   dual;
  END;