create trigger PROJECT_AI
	before insert
	on PROJECT
	for each row
begin 
  select project_sequence.NEXTVAL
  into :new.id
  from dual;
END;
  
