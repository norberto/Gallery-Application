package edu.norbertzardin.dao;

import edu.norbertzardin.entities.Message;

public interface MessageDao {
    int createMessage(Message message);
}
