package edu.norbertzardin.dao.impl;

import edu.norbertzardin.dao.MessageDao;
import edu.norbertzardin.entities.Message;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.*;

@Repository
@Transactional
public class MessageDAOImpl implements MessageDao {

    @PersistenceContext(name = "messagePersistence")
    private EntityManager entityManager;

    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public int createMessage(Message message) {
        entityManager = sessionFactory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.persist(message);
        entityManager.getTransaction().commit();
        entityManager.close();

        return message.getId();
    }
}