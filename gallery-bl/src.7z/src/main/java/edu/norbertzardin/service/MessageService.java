package edu.norbertzardin.service;

import edu.norbertzardin.dao.MessageDao;
import edu.norbertzardin.entities.Message;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("messageService")
public class MessageService {
    @Autowired
    private MessageDao messageDao;

    @Autowired
    public void setMessageDao(MessageDao messageDao) {
        this.messageDao = messageDao;
    }

    @Transactional
    public void createMessage(String message) {
        messageDao.createMessage(new Message(message));
    }


}
